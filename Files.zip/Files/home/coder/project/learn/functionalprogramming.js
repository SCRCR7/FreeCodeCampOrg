// Task 1: Build a function-based console log message generator
function consoleStyler() {
    
}

// Task 2: Build another console log message generator
function celebrateStyler() {
    
}

// Task 3: Run both the consoleStyler and the celebrateStyler functions


// Task 4: Insert a congratulatory and custom message
function styleAndCelebrate() {
    
}
// Call styleAndCelebrate